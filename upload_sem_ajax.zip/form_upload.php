<form action="recebe_upload.php" method="post" enctype="multipart/form-data">
<p>Imagens:
<input type="file" name="nome_arquivo_no_form" />
<input type="submit" value="Enviar" />
</p>
</form>